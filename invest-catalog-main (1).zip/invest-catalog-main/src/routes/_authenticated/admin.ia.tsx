import { useMemo, useState } from "react";
import { Link, createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { AlertTriangle, Sparkles, Wand2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { PhotoFrame } from "@/components/PhotoFrame";
import { cn } from "@/lib/utils";
import {
  fillSpecificationsWithAi,
  generateMachineImage,
  parseMachineWithAi,
  publishMachineFromAi,
} from "@/lib/ai.functions";

import type { MachineDraft } from "@/lib/machineAi.schemas";
import { formatBRL } from "@/lib/format";
import {
  STATUS_OPTIONS,
  fetchCategories,
  fetchMachines,
  normalizeText,
  signImage,
  type MachineStatus,
} from "@/lib/catalog";

export const Route = createFileRoute("/_authenticated/admin/ia")({
  head: () => ({
    meta: [
      { title: "Cadastrar Máquina com IA — Invest Intermediação" },
      {
        name: "description",
        content:
          "Cole a descrição da máquina e a IA preenche marca, modelo, valores e gera a imagem ilustrativa.",
      },
      { property: "og:title", content: "Cadastrar Máquina com IA" },
      {
        property: "og:description",
        content: "Cadastro automático de máquinas com interpretação de texto e imagem ilustrativa.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AdminAiPage,
});

const EMPTY: MachineDraft = {
  brand: "",
  model: "",
  category: "",
  price: null,
  down_payment: null,
  installment: null,
  year: null,
  power: null,
  operating_weight: null,
  hours: "0 horas",
  location: null,
  description: null,
  notes: null,
  condition: "NOVA DE FÁBRICA",
  max_digging_depth: null,
  bucket_capacity: null,
  bucket_capacity_front: null,
  bucket_capacity_rear: null,
  max_reach: null,
  dump_height: null,
  engine: null,
  transmission: null,
  hydraulic_system: null,
  hydraulic_flow: null,
  hydraulic_pressure: null,
  digging_force: null,
  dimensions: null,
  tank_capacity: null,
  max_speed: null,
  qualities: null,
  applications: null,
};


function AdminAiPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const categories = useQuery({ queryKey: ["categories"], queryFn: fetchCategories });
  const machines = useQuery({ queryKey: ["machines"], queryFn: fetchMachines });

  const parseFn = useServerFn(parseMachineWithAi);
  const imageFn = useServerFn(generateMachineImage);
  const publishFn = useServerFn(publishMachineFromAi);

  const [text, setText] = useState("");
  const [draft, setDraft] = useState<MachineDraft>(EMPTY);
  const [status, setStatus] = useState<MachineStatus>("disponivel");
  const [storagePath, setStoragePath] = useState<string | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const parse = useMutation({
    mutationFn: () => parseFn({ data: { text } }),
    onSuccess: (data) => {
      setDraft(data as MachineDraft);
      toast.success("Dados interpretados pela IA. Revise antes de publicar.");
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const generate = useMutation({
    mutationFn: async () => {
      const result = await imageFn({
        data: { brand: draft.brand, model: draft.model, category: draft.category },
      });
      const url = await signImage({ image_url: result.storagePath, storage_path: result.storagePath });
      return { ...result, url };
    },
    onSuccess: (result) => {
      setStoragePath(result.storagePath);
      setPreviewUrl(result.url);
      toast.success("Imagem ilustrativa gerada!");
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const publish = useMutation({
    mutationFn: (machineId: string | null) =>
      publishFn({ data: { machineId, storagePath, status, machine: draft } }),
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["machines"] });
      queryClient.invalidateQueries({ queryKey: ["all-ai-images"] });
      toast.success("Máquina cadastrada!");
      navigate({ to: "/admin/maquinas/$id", params: { id: result.id } });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  /** Correspondência por marca + modelo ou pelo nome oficial (display_name) do banco. */
  const duplicate = useMemo(() => {
    const brand = normalizeText(draft.brand);
    const model = normalizeText(draft.model);
    if (!brand || !model) return null;
    const official = normalizeText(`${draft.brand} ${draft.model}`);
    return (
      (machines.data ?? []).find(
        (row) =>
          (normalizeText(row.brand) === brand && normalizeText(row.model) === model) ||
          normalizeText(row.display_name) === official,
      ) ?? null
    );
  }, [machines.data, draft.brand, draft.model]);


  const set = (patch: Partial<MachineDraft>) => setDraft({ ...draft, ...patch });
  const num = (value: string) => (value.trim() === "" ? null : Number(value.replace(",", ".")));

  return (
    <section className="space-y-5">
      <div>
        <h2 className="font-display text-2xl font-bold uppercase">Cadastrar máquina com IA</h2>
        <p className="text-sm text-muted-foreground">
          Cole o texto recebido (ex.: “Retroescavadeira CAT 416 2018, valor R$ 437.183,03, entrada R$
          39.435,06, parcelas R$ 3.953,72”). Os valores informados são mantidos exatamente.
        </p>
      </div>

      <div className="space-y-3 rounded-xl border bg-card p-4 shadow-card">
        <Label htmlFor="ai-text">Descrição da máquina</Label>
        <Textarea
          id="ai-text"
          rows={6}
          value={text}
          maxLength={4000}
          onChange={(event) => setText(event.target.value)}
          placeholder="Cole aqui a descrição livre da máquina..."
        />
        <Button
          size="lg"
          onClick={() => parse.mutate()}
          disabled={parse.isPending || text.trim().length < 3}
        >
          <Sparkles className="size-4" /> {parse.isPending ? "INTERPRETANDO..." : "INTERPRETAR COM IA"}
        </Button>
      </div>

      <div className="grid gap-4 rounded-xl border bg-card p-4 shadow-card sm:grid-cols-2">
        <Field label="Marca" value={draft.brand} onChange={(v) => set({ brand: v })} />
        <Field label="Modelo" value={draft.model} onChange={(v) => set({ model: v })} />
        <div className="space-y-1.5">
          <Label htmlFor="ai-category">Categoria</Label>
          <Input
            id="ai-category"
            list="ai-category-options"
            value={draft.category}
            onChange={(event) => set({ category: event.target.value })}
          />
          <datalist id="ai-category-options">
            {(categories.data ?? []).map((row) => (
              <option key={row.id} value={row.name} />
            ))}
          </datalist>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="ai-status">Status</Label>
          <select
            id="ai-status"
            value={status}
            onChange={(event) => setStatus(event.target.value as MachineStatus)}
            className="h-10 w-full rounded-md border bg-background px-3 text-sm"
          >
            {STATUS_OPTIONS.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
        <Field
          label="💰 Valor (R$)"
          value={draft.price === null ? "" : String(draft.price)}
          onChange={(v) => set({ price: num(v) })}
        />
        <Field
          label="💳 Entrada (R$)"
          value={draft.down_payment === null ? "" : String(draft.down_payment)}
          onChange={(v) => set({ down_payment: num(v) })}
        />
        <Field
          label="📆 Parcela (R$)"
          value={draft.installment === null ? "" : String(draft.installment)}
          onChange={(v) => set({ installment: num(v) })}
        />
        <Field
          label="Ano"
          value={draft.year === null ? "" : String(draft.year)}
          onChange={(v) => set({ year: v.trim() === "" ? null : Number(v) })}
        />
        <Field label="Potência" value={draft.power ?? ""} onChange={(v) => set({ power: v || null })} />
        <Field
          label="Peso operacional"
          value={draft.operating_weight ?? ""}
          onChange={(v) => set({ operating_weight: v || null })}
        />
        <Field label="Horímetro" value={draft.hours ?? ""} onChange={(v) => set({ hours: v || null })} />
        <Field
          label="Localização"
          value={draft.location ?? ""}
          onChange={(v) => set({ location: v || null })}
        />
        <div className="space-y-1.5 sm:col-span-2">
          <Label htmlFor="ai-description">Descrição</Label>
          <Textarea
            id="ai-description"
            rows={4}
            value={draft.description ?? ""}
            onChange={(event) => set({ description: event.target.value || null })}
          />
        </div>
      </div>

      <div className="space-y-3 rounded-xl border bg-card p-4 shadow-card">
        <h3 className="font-display text-lg font-bold uppercase">Imagem ilustrativa</h3>
        <p className="text-sm text-muted-foreground">
          O catálogo exibe apenas imagens ilustrativas geradas por IA — nunca fotos reais.
        </p>
        <PhotoFrame
          src={previewUrl}
          alt="Imagem ilustrativa gerada por IA"
          className="aspect-[4/3] w-full max-w-md rounded-lg border"
        />
        <Button
          variant="secondary"
          size="lg"
          onClick={() => generate.mutate()}
          disabled={generate.isPending || !draft.model.trim()}
        >
          <Wand2 className="size-4" />
          {generate.isPending ? "GERANDO IMAGEM..." : "GERAR IMAGEM ILUSTRATIVA"}
        </Button>
      </div>

      {duplicate ? (
        <div className="space-y-3 rounded-xl border border-status-negotiating/50 bg-status-negotiating/10 p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="mt-0.5 size-5 shrink-0 text-status-negotiating" aria-hidden />
            <div className="min-w-0">
              <p className="font-display text-sm font-bold uppercase tracking-wide">
                Já existe uma máquina semelhante no catálogo.
              </p>
              <p className="mt-1 text-sm">
                <span className="font-semibold">{duplicate.display_name}</span>
                {duplicate.code ? ` · #${duplicate.code}` : ""} · {duplicate.category}
              </p>
              <p className="text-xs text-muted-foreground">
                Valor {formatBRL(duplicate.price)} · Entrada {formatBRL(duplicate.down_payment)} ·
                Parcela {formatBRL(duplicate.installment)}
              </p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button asChild variant="secondary" size="sm">
              <Link to="/admin/maquinas/$id" params={{ id: duplicate.id }}>
                USAR EXISTENTE
              </Link>
            </Button>
            <Button
              variant="accent"
              size="sm"
              onClick={() => publish.mutate(duplicate.id)}
              disabled={publish.isPending}
            >
              ATUALIZAR EXISTENTE
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => publish.mutate(null)}
              disabled={publish.isPending}
            >
              CRIAR NOVO
            </Button>
          </div>
        </div>
      ) : null}

      <Button
        size="lg"
        className="w-full"
        onClick={() => publish.mutate(null)}
        disabled={publish.isPending || !draft.brand.trim() || !draft.model.trim()}
      >
        {publish.isPending ? "PUBLICANDO..." : "PUBLICAR NO CATÁLOGO"}
      </Button>

      <div className="mt-8 border-t pt-8">
        <h2 className="font-display text-2xl font-bold uppercase">Preenchimento em Massa</h2>
        <p className="mb-4 text-sm text-muted-foreground">
          🤖 Esta ferramenta percorre o catálogo e preenche as especificações técnicas faltantes usando IA.
        </p>
        <MassFillTool />
      </div>


    </section>
  );
}

function MassFillTool() {
  const queryClient = useQueryClient();
  const machines = useQuery({ queryKey: ["machines"], queryFn: fetchMachines });
  const fillFn = useServerFn(fillSpecificationsWithAi);
  const publishFn = useServerFn(publishMachineFromAi);

  const [processing, setProcessing] = useState(false);
  const [current, setCurrent] = useState(0);
  const [log, setLog] = useState<{ id: string; name: string; status: "pending" | "success" | "error"; pendingFields: string[] }[]>([]);
  const [report, setReport] = useState<{ total: number; updated: number; specsFilled: number; notConfirmed: number } | null>(null);

  const startMassFill = async () => {
    const data = machines.data;
    if (!data || processing) return;
    setProcessing(true);
    setReport(null);
    setLog(data.map(m => ({ id: m.id, name: m.display_name, status: "pending", pendingFields: [] })));
    
    let updatedCount = 0;
    let totalNotConfirmed = 0;

    for (let i = 0; i < data.length; i++) {
      const machine = data[i];
      if (!machine) continue;
      setCurrent(i + 1);
      
      try {
        const draft = await fillFn({ data: { machineId: machine.id } });
        await publishFn({ data: { 
          machineId: machine.id, 
          storagePath: null, 
          status: (machine.status || "disponivel") as MachineStatus, 
          machine: draft as MachineDraft 
        } });
        
        updatedCount++;
        const mid = machine.id;
        
        // Auditoria imediata do draft
        const notConfirmed = Object.entries(draft)
          .filter(([key, value]) => value === "Não confirmado" || value === null || value === "")
          .map(([key]) => key);
        
        totalNotConfirmed += notConfirmed.length;

        setLog(prev => prev.map(item => item.id === mid ? { 
          ...item, 
          status: "success", 
          pendingFields: notConfirmed 
        } : item));
      } catch (error) {
        const mname = machine.display_name;
        const mid = machine.id;
        console.error(`Erro ao processar ${mname}:`, error);
        setLog(prev => prev.map(item => item.id === mid ? { ...item, status: "error", pendingFields: [] } : item));
      }
    }
    
    setProcessing(false);
    setReport({
      total: data.length,
      updated: updatedCount,
      specsFilled: data.length * 20 - totalNotConfirmed, // Estimativa
      notConfirmed: totalNotConfirmed
    });
    queryClient.invalidateQueries({ queryKey: ["machines"] });
    toast.success("Processamento em massa concluído!");
  };

  return (
    <div className="space-y-6 rounded-xl border bg-card p-6 shadow-card">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-lg font-bold">Catálogo: {machines.data?.length ?? 0} máquinas.</p>
          {processing && (
            <p className="text-sm text-accent animate-pulse">
              Processando: {current} / {machines.data?.length}
            </p>
          )}
        </div>
        <Button onClick={startMassFill} disabled={processing || !machines.data?.length} size="lg">
          <Wand2 className={`size-4 ${processing ? 'animate-spin' : ''}`} />
          {processing ? "PROCESSANDO..." : "PREENCHER TODAS COM IA"}
        </Button>
      </div>

      {report && (
        <div className="grid grid-cols-2 gap-4 rounded-lg bg-accent/5 p-4 border border-accent/20 sm:grid-cols-4">
          <Stat label="Total" value={report.total} />
          <Stat label="Atualizadas" value={report.updated} />
          <Stat label="Campos OK" value={report.specsFilled} />
          <Stat label="Pendentes" value={report.notConfirmed} color="text-amber-500" />
        </div>
      )}

      {log.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Log de Auditoria</h4>
          <div className="max-h-80 overflow-y-auto rounded-lg border bg-muted/30 p-2 text-xs space-y-1">
            {log.map((item) => (
              <div key={item.id} className="border-b border-muted py-2 last:border-0">
                <div className="flex items-center justify-between">
                  <span className="font-bold truncate pr-2">{item.name}</span>
                  <span className={
                    item.status === "success" ? "text-status-available font-bold" : 
                    item.status === "error" ? "text-status-sold font-bold" : 
                    "text-muted-foreground"
                  }>
                    {item.status === "success" ? "✓ CONCLUÍDO" : 
                     item.status === "error" ? "⚠ ERRO" : 
                     "AGUARDANDO..."}
                  </span>
                </div>
                {item.pendingFields.length > 0 && (
                  <p className="mt-1 text-[10px] text-amber-500 italic">
                    Pendentes: {item.pendingFields.join(", ")}
                  </p>
                )}
                {item.status === "success" && item.pendingFields.length === 0 && (
                  <p className="mt-1 text-[10px] text-green-500">
                    ✅ TODAS AS ESPECIFICAÇÕES FORAM PREENCHIDAS
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function Stat({ label, value, color }: { label: string; value: number; color?: string }) {
  return (
    <div>
      <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className={cn("text-xl font-bold font-display", color)}>{value}</p>
    </div>
  );
}

function Field({

  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  const id = `ai-${label.replace(/[^a-z]/gi, "").toLowerCase()}`;
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id}>{label}</Label>
      <Input id={id} value={value} onChange={(event) => onChange(event.target.value)} />
    </div>
  );
}
