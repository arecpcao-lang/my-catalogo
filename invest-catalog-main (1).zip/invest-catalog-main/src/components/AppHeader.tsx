import { Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { LogOut, Settings2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useCurrentUser } from "@/hooks/useCurrentUser";
import { BrandLogo } from "@/components/BrandLogo";
import { ThemeToggle } from "@/components/ThemeToggle";


export function AppHeader({ companyName }: { companyName?: string | null | undefined }) {
  const { data: user } = useCurrentUser();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  async function handleSignOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <header className="glass-strong sticky top-0 z-30 rounded-none border-x-0 border-t-0 border-b border-sidebar-border bg-gradient-to-r from-background via-surface to-tech-deep/40 text-surface-foreground">
      <div className="mx-auto grid max-w-6xl grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-4 py-3 sm:grid-cols-[1fr_auto_1fr]">
        <div className="min-w-0">
          <Link to="/catalogo" className="flex min-w-0 items-center gap-2.5">
            <BrandLogo size="sm" />
            <p className="truncate font-display text-base font-extrabold uppercase leading-tight tracking-wide sm:text-lg">
              {companyName || "INVEST INTERMEDIAÇÃO"}
            </p>
          </Link>
        </div>

        <h1 className="hidden justify-self-center whitespace-nowrap font-display text-sm font-semibold uppercase tracking-[0.22em] text-accent sm:block">
          Catálogo de Máquinas
        </h1>

        <div className="flex shrink-0 items-center gap-2 justify-self-end">
          <div className="hidden text-right sm:block">
            <p className="truncate font-semibold leading-tight">{user?.name ?? "—"}</p>
            <p className="label-eyebrow text-surface-foreground/60">{user?.roleLabel ?? ""}</p>
          </div>
          <ThemeToggle />
          {user?.isAdmin ? (
            <Button asChild variant="accent" size="sm">
              <Link to="/admin">
                <Settings2 className="size-4" />
                <span className="hidden sm:inline">ADMINISTRAÇÃO</span>
              </Link>
            </Button>
          ) : null}
          <Button variant="outline" size="sm" onClick={handleSignOut} className="bg-transparent text-surface-foreground">
            <LogOut className="size-4" />
            <span className="hidden sm:inline">SAIR</span>
          </Button>
        </div>
      </div>
      <span className="hairline-steel block h-px w-full" aria-hidden />
      <div className="flex items-center justify-between border-t border-sidebar-border px-4 py-1.5 text-xs sm:hidden">
        <span className="font-display font-semibold uppercase tracking-[0.18em] text-accent">
          Catálogo de Máquinas
        </span>
        <span className="truncate text-surface-foreground/70">
          {user?.name ?? "—"} · {user?.roleLabel ?? ""}
        </span>
      </div>
    </header>
  );
}

