import { ImageOff } from "lucide-react";
import { cn } from "@/lib/utils";

export function PhotoFrame({
  src,
  alt,
  className,
  imageClassName,
  showIllustrative = true,
}: {
  src?: string | null | undefined;
  alt: string;
  className?: string | undefined;
  imageClassName?: string | undefined;
  /** Todas as imagens do catálogo são ilustrativas; oculte apenas em miniaturas. */
  showIllustrative?: boolean;
}) {
  return (
    <div className={cn("relative overflow-hidden bg-secondary", className)}>
      {src ? (
        <>
          <img
            src={src}
            alt={alt}
            loading="lazy"
            className={cn("h-full w-full object-cover", imageClassName)}
          />
          {showIllustrative ? (
            <span className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/65 to-transparent px-2 pb-1 pt-4 text-center text-[10px] font-medium uppercase tracking-[0.12em] text-white/90">
              Imagem ilustrativa
            </span>
          ) : null}
        </>
      ) : (
        <div className="flex h-full w-full flex-col items-center justify-center gap-2 bg-[repeating-linear-gradient(45deg,var(--color-secondary),var(--color-secondary)_12px,var(--color-muted)_12px,var(--color-muted)_24px)] text-muted-foreground">
          <ImageOff className="size-7" aria-hidden />
          <span className="font-display text-xs font-semibold uppercase tracking-[0.2em]">
            Foto da máquina
          </span>
        </div>
      )}
    </div>
  );
}
