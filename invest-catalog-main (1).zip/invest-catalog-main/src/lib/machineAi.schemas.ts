import { z } from "zod";

/** A IA às vezes devolve valores como "R$ 250.000,00" — normalizamos para número. */
const moneyLike = z.preprocess((value) => {
  if (value === null || value === undefined || value === "") return null;
  if (typeof value === "number") return value;
  if (typeof value !== "string") return value;
  const cleaned = value.replace(/[^\d,.-]/g, "").replace(/\.(?=\d{3}\b)/g, "").replace(",", ".");
  const parsed = Number(cleaned);
  return Number.isFinite(parsed) ? parsed : null;
}, z.number().nullable().default(null));

const yearLike = z.preprocess((value) => {
  if (value === null || value === undefined || value === "") return null;
  if (typeof value === "number") return value;
  if (typeof value !== "string") return value;
  const match = value.match(/\d{4}/);
  return match ? Number(match[0]) : null;
}, z.number().int().min(1900).max(2100).nullable().default(null));

export const machineDraftSchema = z.object({
  brand: z.string().trim().max(80).default(""),
  model: z.string().trim().max(120).default(""),
  category: z.string().trim().max(80).default(""),
  price: moneyLike,
  down_payment: moneyLike,
  installment: moneyLike,
  year: yearLike,

  power: z.string().trim().max(120).nullable().default(null),
  operating_weight: z.string().trim().max(120).nullable().default(null),
  hours: z.string().trim().max(120).nullable().default(null),
  location: z.string().trim().max(160).nullable().default(null),
  description: z.string().trim().max(2000).nullable().default(null),
  notes: z.string().trim().max(2000).nullable().default(null),
  condition: z.string().trim().max(80).default("NOVA DE FÁBRICA"),
  // Novos campos técnicos detalhados
  max_digging_depth: z.string().trim().max(80).nullable().default(null),
  bucket_capacity: z.string().trim().max(80).nullable().default(null),
  bucket_capacity_front: z.string().trim().max(80).nullable().default(null),
  bucket_capacity_rear: z.string().trim().max(80).nullable().default(null),
  max_reach: z.string().trim().max(80).nullable().default(null),
  dump_height: z.string().trim().max(80).nullable().default(null),
  engine: z.string().trim().max(200).nullable().default(null),
  transmission: z.string().trim().max(200).nullable().default(null),
  hydraulic_system: z.string().trim().max(200).nullable().default(null),
  hydraulic_flow: z.string().trim().max(80).nullable().default(null),
  hydraulic_pressure: z.string().trim().max(80).nullable().default(null),
  digging_force: z.string().trim().max(80).nullable().default(null),
  dimensions: z.string().trim().max(200).nullable().default(null),
  tank_capacity: z.string().trim().max(80).nullable().default(null),
  max_speed: z.string().trim().max(80).nullable().default(null),
  qualities: z.array(z.string()).nullable().default(null),
  applications: z.array(z.string()).nullable().default(null),
});

export type MachineDraft = z.infer<typeof machineDraftSchema>;

export const parseInputSchema = z.object({
  text: z.string().trim().min(3).max(4000),
});

export const imageInputSchema = z.object({
  brand: z.string().trim().max(80),
  model: z.string().trim().max(120),
  category: z.string().trim().max(80),
});

export const publishInputSchema = z.object({
  machineId: z.string().uuid().nullable().default(null),
  storagePath: z.string().trim().max(300).nullable().default(null),
  status: z.enum(["disponivel", "negociacao", "vendida", "indisponivel"]).default("disponivel"),
  machine: machineDraftSchema,
});
