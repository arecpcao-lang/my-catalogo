import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import {
  Bot,
  ShieldCheck,
  Scale,
  FolderTree,
  History,
  LayoutDashboard,
  LogOut,
  Settings,
  Tags,
  Tractor,
  Users,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar";
import { BrandLogo } from "@/components/BrandLogo";
import { supabase } from "@/integrations/supabase/client";
import { useCurrentUser } from "@/hooks/useCurrentUser";

const ITEMS = [
  { to: "/admin" as const, label: "Dashboard", icon: LayoutDashboard, exact: true },
  { to: "/admin/maquinas" as const, label: "Máquinas", icon: Tractor, exact: false },
  { to: "/admin/ia" as const, label: "Cadastrar com IA", icon: Bot, exact: false },
  { to: "/comparar" as const, label: "Comparar", icon: Scale, exact: false },
  { to: "/admin/marcas" as const, label: "Marcas", icon: Tags, exact: false },
  { to: "/admin/categorias" as const, label: "Categorias", icon: FolderTree, exact: false },
  { to: "/admin/usuarios" as const, label: "Usuários", icon: Users, exact: false },
  { to: "/admin/auditoria" as const, label: "Auditoria", icon: ShieldCheck, exact: false },
  { to: "/admin/historico" as const, label: "Histórico", icon: History, exact: false },
  { to: "/admin/configuracoes" as const, label: "Configurações", icon: Settings, exact: false },
];

export function AdminSidebar() {
  const pathname = useRouterState({ select: (router) => router.location.pathname });
  const { data: user } = useCurrentUser();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const isActive = (to: string, exact: boolean) =>
    exact ? pathname === to || pathname === `${to}/` : pathname.startsWith(to);

  async function handleSignOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <Sidebar collapsible="icon" className="border-sidebar-border">
      <SidebarHeader className="border-b border-sidebar-border">
        <Link to="/catalogo" className="flex min-w-0 items-center gap-2.5 px-1 py-1.5">
          <BrandLogo size="sm" />
          <span className="min-w-0 group-data-[collapsible=icon]:hidden">
            <span className="block truncate font-display text-sm font-extrabold uppercase leading-tight tracking-wide">
              Invest
            </span>
            <span className="block truncate text-[0.65rem] uppercase tracking-[0.18em] text-sidebar-foreground/60">
              Painel Admin
            </span>
          </span>
        </Link>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Gestão</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {ITEMS.map((item) => (
                <SidebarMenuItem key={item.to}>
                  <SidebarMenuButton asChild isActive={isActive(item.to, item.exact)} tooltip={item.label}>
                    <Link to={item.to} className="flex items-center gap-2">
                      <item.icon className="size-4 shrink-0" />
                      <span className="truncate font-display text-sm font-semibold uppercase tracking-wide">
                        {item.label}
                      </span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Catálogo</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton asChild tooltip="Ver catálogo">
                  <Link to="/catalogo" className="flex items-center gap-2">
                    <Tractor className="size-4 shrink-0" />
                    <span className="truncate font-display text-sm font-semibold uppercase tracking-wide">
                      Ver catálogo
                    </span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t border-sidebar-border">
        <div className="min-w-0 px-1 pb-1 group-data-[collapsible=icon]:hidden">
          <p className="truncate text-sm font-semibold">{user?.name ?? "—"}</p>
          <p className="label-eyebrow text-sidebar-foreground/60">{user?.roleLabel ?? ""}</p>
        </div>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton onClick={handleSignOut} tooltip="Sair">
              <LogOut className="size-4 shrink-0" />
              <span className="font-display text-sm font-semibold uppercase tracking-wide">Sair</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}
