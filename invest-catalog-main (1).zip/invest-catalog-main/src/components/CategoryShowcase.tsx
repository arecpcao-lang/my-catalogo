import { categoryIcon, type CountedOption } from "@/lib/catalogView";
import { cn } from "@/lib/utils";

/** Seções visuais CATEGORIAS e MARCAS — funcionam como filtros do catálogo. */
export function CategoryShowcase({
  categories,
  brands,
  category,
  brand,
  onCategory,
  onBrand,
  allValue,
}: {
  categories: CountedOption[];
  brands: CountedOption[];
  category: string;
  brand: string;
  onCategory: (value: string) => void;
  onBrand: (value: string) => void;
  allValue: string;
}) {
  if (categories.length === 0 && brands.length === 0) return null;

  return (
    <div className="mb-6 space-y-5">
      {categories.length ? (
        <section>
          <header className="mb-2.5 flex items-center gap-3">
            <h2 className="font-display text-sm font-bold uppercase tracking-[0.22em] text-accent">
              Categorias
            </h2>
            <span className="h-px flex-1 bg-border" />
          </header>
          <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-4">
            {categories.filter(c => !c.name.toUpperCase().includes("4X4") && !c.name.toUpperCase().includes("4 X 4")).map((item, index) => {
              const Icon = categoryIcon(item.name);
              const active = category === item.name;
              return (
                <button
                  key={item.name}
                  type="button"
                  onClick={() => onCategory(active ? allValue : item.name)}
                  aria-pressed={active}
                  className={cn(
                    "glass enter-up group flex cursor-pointer items-center gap-3 rounded-2xl p-3 text-left transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lift",
                    active ? "border-accent/60 shadow-lift" : "hover:border-accent/35",
                  )}
                  style={{ animationDelay: `${index * 40}ms` }}
                >
                  <span
                    className={cn(
                      "flex size-10 shrink-0 items-center justify-center rounded-xl border transition-colors",
                      active
                        ? "border-accent bg-accent text-accent-foreground"
                        : "border-accent/30 bg-accent/10 text-accent",
                    )}
                  >
                    <Icon className="size-4" aria-hidden />
                  </span>
                  <span className="min-w-0">
                    <span className="block truncate font-display text-sm font-bold uppercase leading-tight">
                      {item.name}
                    </span>
                    <span className="block text-xs text-muted-foreground">
                      {item.count} {item.count === 1 ? "modelo" : "modelos"}
                    </span>
                  </span>
                </button>
              );
            })}
          </div>
        </section>
      ) : null}

      {brands.length ? (
        <section>
          <header className="mb-2.5 flex items-center gap-3">
            <h2 className="font-display text-sm font-bold uppercase tracking-[0.22em] text-accent">
              Marcas
            </h2>
            <span className="h-px flex-1 bg-border" />
          </header>
          <div className="scroll-x-clean -mx-4 px-4">
            <div className="flex w-max gap-2.5 pb-1">
              {brands.filter(b => !b.name.toUpperCase().includes("4X4") && !b.name.toUpperCase().includes("4 X 4")).map((item) => {
                const active = brand === item.name;
                return (
                  <button
                    key={item.name}
                    type="button"
                    onClick={() => onBrand(active ? allValue : item.name)}
                    aria-pressed={active}
                    className={cn(
                      "glass shrink-0 cursor-pointer rounded-2xl px-4 py-2.5 text-center transition-all duration-300 hover:-translate-y-0.5 hover:border-accent/35",
                      active && "border-accent/60 shadow-lift",
                    )}
                  >
                    <span className="block font-display text-sm font-extrabold uppercase tracking-wide">
                      {item.name}
                    </span>
                    <span className="block text-[0.68rem] uppercase tracking-[0.16em] text-muted-foreground">
                      {item.count} {item.count === 1 ? "máquina" : "máquinas"}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </section>
      ) : null}
    </div>
  );
}
