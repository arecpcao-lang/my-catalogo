import { illustrativeImage } from "@/lib/machineImages";
import type { Machine } from "@/lib/catalog";

/** Faixa de destaque do catálogo — composição visual com imagens ilustrativas. */
export function CatalogHero({ machines }: { machines: Machine[] }) {
  const showcase = machines
    .map((machine) => illustrativeImage(machine))
    .filter((src): src is string => Boolean(src))
    .filter((src, index, all) => all.indexOf(src) === index)
    .slice(0, 3);

  return (
    <section className="enter-up relative mb-6 overflow-hidden rounded-[1.75rem] border bg-gradient-to-br from-background via-surface to-tech-deep/60 shadow-lift">
      <div className="pointer-events-none absolute -right-24 -top-24 size-72 rounded-full bg-accent/10 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-28 -left-20 size-80 rounded-full bg-tech/15 blur-3xl" />
      <div className="grid items-center gap-5 p-5 sm:p-7 lg:grid-cols-[1.1fr_1fr]">
        <div className="min-w-0">
          <p className="label-eyebrow text-accent">Invest Intermediação</p>
          <h2 className="mt-1 font-display text-3xl font-extrabold uppercase leading-[1.05] tracking-tight text-surface-foreground sm:text-5xl">
            Catálogo de <span className="text-accent">Máquinas</span>
          </h2>
          <p className="mt-2 max-w-md text-sm text-surface-foreground/70 sm:text-base">
            Consulte rapidamente modelos, valores e condições durante o atendimento.
          </p>
          <div className="mt-4 flex items-center gap-3">
            <span className="h-1 w-24 rounded-full bg-accent" />
            <span className="chip-tech rounded-full px-2.5 py-1 font-display text-[0.65rem] font-bold uppercase tracking-[0.18em]">
              Máquinas novas de fábrica
            </span>
          </div>
        </div>

        {showcase.length ? (
          <div className="grid grid-cols-3 gap-2">
            {showcase.map((src, index) => (
              <div
                key={src}
                className="enter-up overflow-hidden rounded-xl border border-border/60"
                style={{ animationDelay: `${120 + index * 90}ms` }}
              >
                <img
                  src={src}
                  alt="Imagem ilustrativa de máquina do catálogo"
                  loading="lazy"
                  className="aspect-square w-full object-cover transition-transform duration-500 hover:scale-105"
                />
              </div>
            ))}
          </div>
        ) : null}
      </div>
    </section>
  );
}
