import { STATUS_META, type MachineStatus } from "@/lib/catalog";
import { cn } from "@/lib/utils";

export function StatusBadge({ status, className }: { status: string; className?: string }) {
  const meta = STATUS_META[(status as MachineStatus) in STATUS_META ? (status as MachineStatus) : "indisponivel"];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-surface/85 px-2.5 py-1 font-display text-[0.68rem] font-semibold uppercase tracking-[0.14em] text-surface-foreground",
        className,
      )}
    >
      <span className={cn("size-2 rounded-full", meta.color)} aria-hidden />
      {meta.label}
    </span>
  );
}
