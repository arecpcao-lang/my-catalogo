import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { machineDraftSchema, type MachineDraft } from "@/lib/machineAi.schemas";

export type AiAuthContext = {
  supabase: SupabaseClient<Database>;
  userId: string;
};

const GATEWAY = "https://ai.gateway.lovable.dev/v1";

export async function assertAdminAi(context: AiAuthContext) {
  const { data, error } = await context.supabase
    .from("user_roles")
    .select("role")
    .eq("user_id", context.userId)
    .eq("role", "admin")
    .maybeSingle();
  if (error || !data) throw new Error("Apenas administradores podem usar o cadastro com IA.");
}

function apiKey(): string {
  const key = process.env["LOVABLE_API_KEY"];
  if (!key) throw new Error("A IA não está configurada: falta a chave LOVABLE_API_KEY no backend.");
  return key;
}

const SYSTEM_PROMPT = `Você é um especialista em máquinas pesadas (retroescavadeiras, escavadeiras, etc).
Extraia dados técnicos de máquinas pesadas a partir de nomes de modelos ou descrições.
Responda APENAS com um objeto JSON válido.

Regras de Negócio:
1. Condição: Sempre "NOVA DE FÁBRICA".
2. Horímetro: Sempre "0 horas".
3. Ano: Use 2026 para a geração atual, a menos que a documentação oficial do modelo indique uma versão específica.
4. Localização: Identifique a fábrica real da marca no Brasil (ex: CATERPILLAR -> Piracicaba - SP, Brasil) ou unidade fabril global principal para o modelo.
5. Especificações: Busque dados oficiais (fabricante, manuais). Não invente números. Se não encontrar um valor confirmado, use o texto exato "Não confirmado". NUNCA use "Não informado", "NULL", "N/A" ou deixe vazio.
6. Campos:
   brand, model, category, price, down_payment, installment, year, power, operating_weight, hours, location, description, notes, condition,
   max_digging_depth, bucket_capacity, bucket_capacity_front, bucket_capacity_rear, max_reach, dump_height, engine, transmission,
   hydraulic_system, hydraulic_flow, hydraulic_pressure, digging_force, dimensions, tank_capacity, max_speed, qualities (array), applications (array).

Categorias oficiais: ESCAVADEIRA, RETROESCAVADEIRA, MINI ESCAVADEIRA, MINI CARREGADEIRA, PÁ CARREGADEIRA, MÁQUINA AGRÍCOLA, CAMINHÃO.
Pesquise pelo MARCA + MODELO EXATO. Adapte os campos técnicos à categoria (ex: caçamba traseira faz sentido para retroescavadeira, não para escavadeira).`;


export async function parseMachineDraft(text: string, isUpdate: boolean = false): Promise<MachineDraft> {
  const prompt = isUpdate 
    ? text 
    : `Extraia dados técnicos de máquinas pesadas a partir de nomes de modelos ou descrições.
       Responda APENAS com um objeto JSON válido.
       Marca, modelo e categoria devem ser preservados se informados.
       Condição: "NOVA DE FÁBRICA".
       Horímetro: "0 horas".
       Ano: 2026 para modelos atuais.
       Localização: Identifique a fábrica no Brasil ou principal global.
       ${text}`;

  const response = await fetch(`${GATEWAY}/chat/completions`, {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey()}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "google/gemini-3.6-flash",
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: prompt },
      ],
      response_format: { type: "json_object" },
    }),
  });

  if (!response.ok) {
    throw new Error(`A IA não conseguiu interpretar o texto (${response.status}).`);
  }
  const json = (await response.json()) as {
    choices?: { message?: { content?: string } }[];
  };
  const raw = json.choices?.[0]?.message?.content ?? "";
  const cleaned = raw.replace(/```json|```/g, "").trim();
  let parsed: unknown;
  try {
    parsed = JSON.parse(cleaned);
  } catch {
    throw new Error("A IA respondeu em um formato inesperado. Tente reescrever o texto.");
  }
  return machineDraftSchema.parse(parsed);
}

export function imagePrompt(input: { brand: string; model: string; category: string }): string {
  const name = `${input.category} ${input.brand} ${input.model}`.replace(/\s+/g, " ").trim();
  return `Imagem ilustrativa fotorrealista de uma ${name}, máquina pesada inteira visível em vista 3/4 frontal, equipamento centralizado, fundo de estúdio neutro claro, iluminação profissional suave, alta qualidade, sem pessoas, sem texto, sem logotipos legíveis, sem marca d'água, sem banners e sem preços.`;
}

/** Gera a imagem ilustrativa e a grava no bucket privado; devolve apenas o caminho. */
export async function generateIllustrativeImage(input: {
  brand: string;
  model: string;
  category: string;
}): Promise<{ storagePath: string }> {
  const response = await fetch(`${GATEWAY}/images/generations`, {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey()}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "google/gemini-3.1-flash-image",
      messages: [{ role: "user", content: imagePrompt(input) }],
      modalities: ["image", "text"],
    }),
  });
  if (!response.ok) {
    throw new Error(`Não foi possível gerar a imagem ilustrativa (${response.status}).`);
  }
  const json = (await response.json()) as { data?: { b64_json?: string }[] };
  const b64 = json.data?.[0]?.b64_json;
  if (!b64) throw new Error("A IA não retornou nenhuma imagem. Tente gerar novamente.");

  const bytes = Uint8Array.from(atob(b64), (char) => char.charCodeAt(0));
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const storagePath = `ia/${crypto.randomUUID()}.png`;
  const { error } = await supabaseAdmin.storage
    .from("machine-photos")
    .upload(storagePath, bytes, { contentType: "image/png", upsert: false });
  if (error) throw new Error(error.message);
  return { storagePath };
}
