import cat416 from "@/assets/machines/cat-416.jpg";
import cat416Lateral from "@/assets/machines/cat-416-lateral.jpg";
import cat416Cabine from "@/assets/machines/cat-416-cabine.jpg";
import jcb3cx from "@/assets/machines/jcb-3cx.jpg";
import jcb3cxLateral from "@/assets/machines/jcb-3cx-lateral.jpg";
import jcb3cxCabine from "@/assets/machines/jcb-3cx-cabine.jpg";
import jcb4cx from "@/assets/machines/jcb-4cx.jpg";
import jcb4cxLateral from "@/assets/machines/jcb-4cx-lateral.jpg";
import jcb4cxCabine from "@/assets/machines/jcb-4cx-cabine.jpg";
import case580n from "@/assets/machines/case-580n.jpg";
import case580nLateral from "@/assets/machines/case-580n-lateral.jpg";
import case580nCabine from "@/assets/machines/case-580n-cabine.jpg";
import volvo220d from "@/assets/machines/volvo-220d.jpg";
import volvo220dLateral from "@/assets/machines/volvo-220d-lateral.jpg";
import volvo220dCabine from "@/assets/machines/volvo-220d-cabine.jpg";
import cat320 from "@/assets/machines/cat-320.jpg";
import cat320Lateral from "@/assets/machines/cat-320-lateral.jpg";
import cat320Cabine from "@/assets/machines/cat-320-cabine.jpg";
import volvoEc140 from "@/assets/machines/volvo-ec140.jpg";
import volvoEc140Lateral from "@/assets/machines/volvo-ec140-lateral.jpg";
import volvoEc140Cabine from "@/assets/machines/volvo-ec140-cabine.jpg";
import cat313 from "@/assets/machines/cat-313.jpg";
import cat313Lateral from "@/assets/machines/cat-313-lateral.jpg";
import cat313Cabine from "@/assets/machines/cat-313-cabine.jpg";
import caseSv185b from "@/assets/machines/case-sv185b.jpg";
import caseSv185bLateral from "@/assets/machines/case-sv185b-lateral.jpg";
import caseSv185bCabine from "@/assets/machines/case-sv185b-cabine.jpg";
import jcb35z from "@/assets/machines/jcb-35z.jpg";
import jcb35zLateral from "@/assets/machines/jcb-35z-lateral.jpg";
import jcb35zCabine from "@/assets/machines/jcb-35z-cabine.jpg";
import cat250 from "@/assets/machines/cat-250.jpg";
import cat250Lateral from "@/assets/machines/cat-250-lateral.jpg";
import cat250Cabine from "@/assets/machines/cat-250-cabine.jpg";
import sanySy16c from "@/assets/machines/sany-sy16c.jpg";
import sanySy16cLateral from "@/assets/machines/sany-sy16c-lateral.jpg";
import sanySy16cCabine from "@/assets/machines/sany-sy16c-cabine.jpg";
import bobcatS450 from "@/assets/machines/bobcat-s450.jpg";
import bobcatS450Lateral from "@/assets/machines/bobcat-s450-lateral.jpg";
import bobcatS450Cabine from "@/assets/machines/bobcat-s450-cabine.jpg";
import paCarregadeira from "@/assets/machines/pa-carregadeira.jpg";
import maquinaAgricola from "@/assets/machines/maquina-agricola.jpg";
import caminhao from "@/assets/machines/caminhao.jpg";
import { normalizeText } from "@/lib/catalog";

export type IllustrativeView = { src: string; label: string };

/**
 * Imagens ILUSTRATIVAS geradas por IA — são o padrão visual do catálogo.
 * Fotos reais enviadas pelo administrador não são exibidas na interface.
 */
type Set = { views: IllustrativeView[] };

function set(main: string, lateral: string, cabine: string): Set {
  return {
    views: [
      { src: main, label: "Vista 3/4 frontal" },
      { src: lateral, label: "Vista lateral" },
      { src: cabine, label: "Cabine" },
    ],
  };
}

const SETS = {
  cat416: set(cat416, cat416Lateral, cat416Cabine),
  jcb3cx: set(jcb3cx, jcb3cxLateral, jcb3cxCabine),
  jcb4cx: set(jcb4cx, jcb4cxLateral, jcb4cxCabine),
  case580n: set(case580n, case580nLateral, case580nCabine),
  volvo220d: set(volvo220d, volvo220dLateral, volvo220dCabine),
  cat320: set(cat320, cat320Lateral, cat320Cabine),
  volvoEc140: set(volvoEc140, volvoEc140Lateral, volvoEc140Cabine),
  cat313: set(cat313, cat313Lateral, cat313Cabine),
  caseSv185b: set(caseSv185b, caseSv185bLateral, caseSv185bCabine),
  jcb35z: set(jcb35z, jcb35zLateral, jcb35zCabine),
  cat250: set(cat250, cat250Lateral, cat250Cabine),
  sanySy16c: set(sanySy16c, sanySy16cLateral, sanySy16cCabine),
  bobcatS450: set(bobcatS450, bobcatS450Lateral, bobcatS450Cabine),
  paCarregadeira: set(paCarregadeira, paCarregadeira, paCarregadeira),
  maquinaAgricola: set(maquinaAgricola, maquinaAgricola, maquinaAgricola),
  caminhao: set(caminhao, caminhao, caminhao),
} satisfies Record<string, Set>;

const BY_MODEL: { match: string[]; set: Set }[] = [
  { match: ["416"], set: SETS.cat416 },
  { match: ["3cx"], set: SETS.jcb3cx },
  { match: ["4cx"], set: SETS.jcb4cx },
  { match: ["580n"], set: SETS.case580n },
  { match: ["220d", "220 d"], set: SETS.volvo220d },
  { match: ["320"], set: SETS.cat320 },
  { match: ["ec140", "140"], set: SETS.volvoEc140 },
  { match: ["313"], set: SETS.cat313 },
  { match: ["sv185"], set: SETS.caseSv185b },
  { match: ["35z"], set: SETS.jcb35z },
  { match: ["250"], set: SETS.cat250 },
  { match: ["sy16"], set: SETS.sanySy16c },
  { match: ["s450"], set: SETS.bobcatS450 },
];

const BY_CATEGORY: { match: string[]; set: Set }[] = [
  { match: ["retroescavadeira"], set: SETS.cat416 },
  { match: ["mini escavadeira"], set: SETS.jcb35z },
  { match: ["mini carregadeira"], set: SETS.bobcatS450 },
  { match: ["escavadeira"], set: SETS.cat320 },
  { match: ["pa carregadeira"], set: SETS.paCarregadeira },
  { match: ["maquina agricola", "agricola"], set: SETS.maquinaAgricola },
  { match: ["caminhao"], set: SETS.caminhao },
];

type MachineLike = {
  brand?: string | null;
  model?: string | null;
  category?: string | null;
};

function resolveSet(machine: MachineLike): Set | null {
  const key = normalizeText(`${machine.brand ?? ""} ${machine.model ?? ""}`);
  for (const entry of BY_MODEL) {
    if (entry.match.some((token) => key.includes(token))) return entry.set;
  }
  const category = normalizeText(machine.category ?? "");
  for (const entry of BY_CATEGORY) {
    if (entry.match.some((token) => category.includes(token))) return entry.set;
  }
  return null;
}

/** Imagem ilustrativa principal (vista 3/4 frontal). Nunca devolve vazio. */
export function illustrativeImage(machine: MachineLike): string {
  return resolveSet(machine)?.views[0]?.src ?? paCarregadeira;
}

/** Galeria ilustrativa: variações da mesma máquina (3/4, lateral, cabine). */
export function illustrativeGallery(machine: MachineLike): IllustrativeView[] {
  const views = resolveSet(machine)?.views;
  if (views?.length) return views;
  return [{ src: paCarregadeira, label: "Vista 3/4 frontal" }];
}
