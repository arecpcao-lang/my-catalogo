import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  AlertTriangle,
  Bot,
  CheckCircle2,
  FolderTree,
  ImageOff,
  Plus,
  Sparkles,
  Tags,
  Tractor,
  type LucideIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/StatusBadge";
import { MachineMedia } from "@/components/MachineMedia";
import { EmptyState } from "@/components/EmptyState";
import {
  fetchAllAiImages,
  fetchCategories,
  fetchMachines,
  machineTitle,
  type Machine,
} from "@/lib/catalog";
import { brandOptions, categoryIcon } from "@/lib/catalogView";
import { illustrativeImage } from "@/lib/machineImages";
import { formatBRL, formatDate } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/admin/")({
  head: () => ({
    meta: [
      { title: "Dashboard do Painel — Invest Intermediação" },
      {
        name: "description",
        content: "Visão geral do catálogo interno: registros, categorias, marcas e pendências técnicas.",
      },
      { property: "og:title", content: "Dashboard do Painel Administrativo" },
      { property: "og:description", content: "Resumo visual do catálogo de máquinas da Invest." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AdminDashboard,
});

/** Campos técnicos considerados na completude da ficha. */
const SPEC_FIELDS = [
  "power",
  "operating_weight",
  "engine",
  "transmission",
  "hydraulic_system",
  "hydraulic_flow",
  "hydraulic_pressure",
  "dimensions",
  "tank_capacity",
  "bucket_capacity",
  "max_reach",
  "dump_height",
  "max_digging_depth",
  "digging_force",
] as const;

const PENDING = new Set(["", "não informado", "nao informado", "não confirmado", "nao confirmado", "n/a", "null"]);

function isFilled(value: unknown): boolean {
  if (typeof value !== "string") return value != null;
  return !PENDING.has(value.trim().toLowerCase());
}

function pendingFields(machine: Machine): number {
  return SPEC_FIELDS.filter((field) => !isFilled(machine[field])).length;
}

function AdminDashboard() {
  const machines = useQuery({ queryKey: ["machines"], queryFn: fetchMachines });
  const categories = useQuery({ queryKey: ["categories"], queryFn: fetchCategories });
  const images = useQuery({ queryKey: ["all-ai-images"], queryFn: fetchAllAiImages });

  const all = machines.data ?? [];
  const brands = brandOptions(all);
  const usedCategories = [...new Set(all.map((machine) => machine.category))];

  const withMedia = new Set((images.data ?? []).map((image) => image.machine_id));
  const withoutMedia = all.filter((machine) => !withMedia.has(machine.id));
  const complete = all.filter((machine) => pendingFields(machine) === 0);
  const pendingTotal = all.reduce((total, machine) => total + pendingFields(machine), 0);

  const byCategory = usedCategories
    .map((name) => ({ name, count: all.filter((machine) => machine.category === name).length }))
    .sort((a, b) => b.count - a.count);

  const recent = [...all]
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
    .slice(0, 5);

  const max = Math.max(1, ...byCategory.map((row) => row.count), ...brands.map((row) => row.count));

  const stats: {
    label: string;
    value: number;
    hint: string;
    icon: LucideIcon;
    to: string;
    search?: Record<string, string>;
    tone?: "accent" | "tech" | "warn" | "ok";
  }[] = [
    { label: "Total de máquinas", value: all.length, hint: "abrir lista completa", icon: Tractor, to: "/admin/maquinas", tone: "accent" },
    { label: "Marcas", value: brands.length, hint: "identificadas nos registros", icon: Tags, to: "/admin/marcas", tone: "tech" },
    { label: "Categorias", value: usedCategories.length, hint: `${categories.data?.length ?? 0} cadastradas`, icon: FolderTree, to: "/admin/categorias", tone: "tech" },
    { label: "Fichas completas", value: complete.length, hint: `${all.length - complete.length} em revisão`, icon: CheckCircle2, to: "/admin/auditoria", tone: "ok" },
    { label: "Pendências técnicas", value: pendingTotal, hint: "campos a confirmar", icon: AlertTriangle, to: "/admin/auditoria", tone: "warn" },
    { label: "Sem mídia própria", value: withoutMedia.length, hint: "gerar imagem com IA", icon: ImageOff, to: "/admin/ia", tone: "warn" },
  ];

  if (machines.isLoading) {
    return (
      <div className="space-y-4">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, index) => (
            <div key={index} className="skeleton-shimmer h-28 rounded-xl" />
          ))}
        </div>
        <div className="skeleton-shimmer h-64 rounded-xl" />
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="glass enter-up grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 rounded-2xl p-4">
        <div className="min-w-0">
          <p className="label-eyebrow text-accent">Invest Intermediação</p>
          <h2 className="font-display text-2xl font-bold uppercase leading-none">Visão geral</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Indicadores em tempo real do catálogo interno de máquinas.
          </p>
        </div>
        <div className="flex shrink-0 gap-2">
          <Button asChild variant="info" size="lg">
            <Link to="/admin/ia">
              <Bot className="size-4" /> <span className="hidden sm:inline">IA</span>
            </Link>
          </Button>
          <Button asChild variant="accent" size="lg">
            <Link to="/admin/maquinas/$id" params={{ id: "nova" }}>
              <Plus className="size-4" /> <span className="hidden sm:inline">NOVA</span>
            </Link>
          </Button>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {stats.map((stat, index) => (
          <Link
            key={stat.label}
            to={stat.to}
            className="enter-up panel group relative overflow-hidden p-4 transition-all duration-300 hover:-translate-y-0.5 hover:border-accent/40 hover:shadow-lift"
            style={{ animationDelay: `${index * 45}ms` }}
          >
            <span
              className={`pointer-events-none absolute inset-x-0 top-0 h-0.5 ${
                stat.tone === "warn"
                  ? "bg-status-negotiating"
                  : stat.tone === "ok"
                    ? "bg-status-available"
                    : stat.tone === "tech"
                      ? "bg-tech"
                      : "bg-accent"
              }`}
              aria-hidden
            />
            <div className="flex items-center justify-between gap-2">
              <p className="label-eyebrow truncate">{stat.label}</p>
              <stat.icon className="size-4 shrink-0 text-accent transition-transform group-hover:scale-110" />
            </div>
            <p className="mt-1 font-display text-4xl font-extrabold leading-none">{stat.value}</p>
            <p className="mt-1 truncate text-xs text-muted-foreground">{stat.hint}</p>
          </Link>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <BarPanel
          title="Máquinas por categoria"
          rows={byCategory.map((row) => ({ ...row, icon: categoryIcon(row.name) }))}
          max={max}
        />
        <BarPanel title="Máquinas por marca" rows={brands} max={max} tone="tech" />
      </div>

      {withoutMedia.length > 0 ? (
        <section className="panel p-4">
          <div className="flex items-center gap-2">
            <ImageOff className="size-4 text-accent" aria-hidden />
            <h3 className="font-display text-lg font-bold uppercase">Máquinas sem mídia própria</h3>
          </div>
          <p className="mt-1 text-xs text-muted-foreground">
            Estas máquinas exibem a imagem ilustrativa padrão da categoria. Gere uma mídia
            específica com IA para deixá-las únicas.
          </p>
          <ul className="mt-3 flex flex-wrap gap-2">
            {withoutMedia.map((machine) => (
              <li key={machine.id}>
                <Link
                  to="/admin/maquinas/$id"
                  params={{ id: machine.id }}
                  className="chip-tech inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold transition-transform hover:scale-[1.03]"
                >
                  <Sparkles className="size-3" aria-hidden /> {machineTitle(machine)}
                </Link>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      <section className="panel p-4">
        <div className="flex items-baseline justify-between gap-2">
          <h3 className="font-display text-lg font-bold uppercase">Últimos cadastros</h3>
          <Link
            to="/admin/maquinas"
            className="font-display text-xs font-semibold uppercase tracking-[0.16em] text-accent hover:underline"
          >
            Ver todas
          </Link>
        </div>

        {recent.length === 0 ? (
          <p className="py-8 text-center text-sm text-muted-foreground">
            Dados insuficientes para exibição.
          </p>
        ) : (
          <ul className="mt-3 space-y-2">
            {recent.map((machine) => (
              <li key={machine.id}>
                <Link
                  to="/admin/maquinas/$id"
                  params={{ id: machine.id }}
                  className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 rounded-xl border border-border/70 bg-secondary/30 p-2 transition-colors hover:border-accent/40"
                >
                  <MachineMedia
                    src={illustrativeImage(machine)}
                    alt={machineTitle(machine)}
                    className="size-12 shrink-0 rounded-lg"
                    showIllustrative={false}
                    showControl={false}
                  />
                  <div className="min-w-0">
                    <p className="truncate font-display text-sm font-bold uppercase">
                      {machineTitle(machine)}
                    </p>
                    <p className="truncate text-xs text-muted-foreground">
                      {machine.category} · {formatDate(machine.created_at)}
                    </p>
                  </div>
                  <div className="shrink-0 text-right">
                    <p className="font-display text-sm font-bold text-accent">{formatBRL(machine.price)}</p>
                    <StatusBadge status={machine.status} className="mt-1" />
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

function BarPanel({
  title,
  rows,
  max,
  tone = "accent",
}: {
  title: string;
  rows: { name: string; count: number; icon?: LucideIcon }[];
  max: number;
  tone?: "accent" | "tech";
}) {
  return (
    <section className="panel p-4">
      <h3 className="font-display text-lg font-bold uppercase">{title}</h3>
      {rows.length === 0 ? (
        <EmptyState icon="📊" title="Dados insuficientes para exibição." />
      ) : (
        <ul className="mt-3 space-y-2.5">
          {rows.map((row) => (
            <li key={row.name}>
              <Link
                to="/admin/maquinas"
                search={{ q: row.name }}
                className="block rounded-lg px-1 py-0.5 transition-colors hover:bg-secondary/50"
              >
                <div className="flex items-baseline justify-between gap-2">
                  <span className="flex min-w-0 items-center gap-1.5 truncate text-sm font-medium">
                    {row.icon ? <row.icon className="size-3.5 shrink-0 text-accent" aria-hidden /> : null}
                    <span className="truncate">{row.name}</span>
                  </span>
                  <span className="font-display text-sm font-bold">{row.count}</span>
                </div>
                <div className="mt-1 h-2 overflow-hidden rounded-full bg-secondary">
                  <div
                    className={`h-full rounded-full transition-[width] duration-700 ${
                      tone === "tech" ? "bg-tech" : "bg-accent"
                    }`}
                    style={{ width: `${Math.round((row.count / max) * 100)}%` }}
                  />
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
