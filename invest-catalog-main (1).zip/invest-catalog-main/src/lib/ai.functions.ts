import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import {
  imageInputSchema,
  parseInputSchema,
  publishInputSchema,
} from "@/lib/machineAi.schemas";
import type { AiAuthContext } from "@/lib/ai.server";

/** Valor confirmado pela IA fica visível; o que ela não confirmou permanece oculto. */
function specStatus(value: string | null | undefined): "confirmed" | "not_confirmed" {
  const text = (value ?? "").trim().toLowerCase();
  if (!text || text.includes("não confirmado") || text.includes("nao confirmado")) {
    return "not_confirmed";
  }
  return "confirmed";
}


export const fillSpecificationsWithAi = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ machineId: z.string().uuid() }).parse(data))
  .handler(async ({ data, context }) => {
    const { assertAdminAi, parseMachineDraft } = await import("@/lib/ai.server");
    const { fetchMachine } = await import("@/lib/catalog");
    const auth = context as unknown as AiAuthContext;
    await assertAdminAi(auth);

    const machine = await fetchMachine(data.machineId);
    if (!machine) throw new Error("Máquina não encontrada.");

    const prompt = `Busque a ficha técnica oficial completa para a máquina:
Marca: ${machine.brand}
Modelo: ${machine.model}
Categoria: ${machine.category}

Importante:
- Se for uma máquina de geração atual, use 2026 como Ano do Catálogo.
- Horímetro deve ser "0 horas".
- Condição deve ser "NOVA DE FÁBRICA".
- Identifique a localização da fábrica da ${machine.brand} para este modelo.
- Preencha TODOS os campos técnicos (potência, peso, profundidade, caçambas, motor, hidráulica, dimensões, etc).
- Liste 6 qualidades principais e 6 aplicações típicas.
- Mantenha os valores comerciais vazios ou null, eles não devem ser alterados.`;

    return parseMachineDraft(prompt, true);
  });



export const parseMachineWithAi = createServerFn({ method: "POST" })


  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => parseInputSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { assertAdminAi, parseMachineDraft } = await import("@/lib/ai.server");
    const auth = context as unknown as AiAuthContext;
    await assertAdminAi(auth);
    return parseMachineDraft(data.text);
  });

export const generateMachineImage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => imageInputSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { assertAdminAi, generateIllustrativeImage } = await import("@/lib/ai.server");
    const auth = context as unknown as AiAuthContext;
    await assertAdminAi(auth);
    return generateIllustrativeImage(data);
  });

export const publishMachineFromAi = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => publishInputSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { assertAdminAi } = await import("@/lib/ai.server");
    const auth = context as unknown as AiAuthContext;
    await assertAdminAi(auth);

    const draft = data.machine;
    if (!draft.brand || !draft.model) throw new Error("Informe ao menos marca e modelo.");

    // Força padrões de negócio
    const payload = {
      brand: draft.brand,
      model: draft.model,
      category: draft.category || "OUTRAS",
      price: draft.price,
      down_payment: draft.down_payment,
      installment: draft.installment,
      year: draft.year || 2026,
      power: draft.power || "Não confirmado",
      operating_weight: draft.operating_weight || "Não confirmado",
      hours: "0 horas",
      location: draft.location || "Não confirmado",
      condition: "NOVA DE FÁBRICA",
      max_digging_depth: draft.max_digging_depth || "Não confirmado",
      bucket_capacity: draft.bucket_capacity || "Não confirmado",
      bucket_capacity_front: draft.bucket_capacity_front || "Não confirmado",
      bucket_capacity_rear: draft.bucket_capacity_rear || "Não confirmado",
      max_reach: draft.max_reach || "Não confirmado",
      dump_height: draft.dump_height || "Não confirmado",
      engine: draft.engine || "Não confirmado",
      transmission: draft.transmission || "Não confirmado",
      hydraulic_system: draft.hydraulic_system || "Não confirmado",
      hydraulic_flow: draft.hydraulic_flow || "Não confirmado",
      hydraulic_pressure: draft.hydraulic_pressure || "Não confirmado",
      digging_force: draft.digging_force || "Não confirmado",
      dimensions: draft.dimensions || "Não confirmado",
      tank_capacity: draft.tank_capacity || "Não confirmado",
      max_speed: draft.max_speed || "Não confirmado",
      qualities: draft.qualities || [],
      applications: draft.applications || [],
      description: draft.description || "Não confirmado",
      notes: draft.notes,
      status: data.status,
      // Especificações trazidas pela IA a partir de fontes oficiais ficam visíveis;
      // apenas o que ela não conseguiu confirmar continua oculto no catálogo.
      technical_source: "IA — fontes oficiais do fabricante",
      technical_last_validated_at: new Date().toISOString(),
      status_power: specStatus(draft.power),
      status_operating_weight: specStatus(draft.operating_weight),
      status_max_digging_depth: specStatus(draft.max_digging_depth),
      status_bucket_capacity: specStatus(draft.bucket_capacity),
      status_max_reach: specStatus(draft.max_reach),
      status_dump_height: specStatus(draft.dump_height),
      status_engine: specStatus(draft.engine),
      status_transmission: specStatus(draft.transmission),
      status_hydraulic_flow: specStatus(draft.hydraulic_flow),
      updated_at: new Date().toISOString(),
    };



    let machineId = data.machineId;
    if (machineId) {
      const { error } = await auth.supabase.from("machines").update(payload).eq("id", machineId);
      if (error) throw new Error(error.message);
    } else {
      const { data: inserted, error } = await auth.supabase
        .from("machines")
        .insert(payload)
        .select("id")
        .single();
      if (error) throw new Error(error.message);
      machineId = inserted.id;
    }

    if (data.storagePath && machineId) {
      // A imagem da IA passa a ser a principal; fotos antigas deixam de ser destaque.
      await auth.supabase.from("machine_images").update({ is_main: false }).eq("machine_id", machineId);
      const { error } = await auth.supabase.from("machine_images").insert({
        machine_id: machineId,
        image_url: data.storagePath,
        storage_path: data.storagePath,
        label: "Imagem ilustrativa (IA)",
        is_main: true,
        sort_order: 0,
        ai_generated: true,
      });
      if (error) throw new Error(error.message);
    }

    return { id: machineId as string };
  });
