import { supabase } from "@/integrations/supabase/client";

export const MACHINE_BUCKET = "machine-photos";

export type MachineStatus = "disponivel" | "negociacao" | "vendida" | "indisponivel";
export type SpecValidationStatus = "confirmed" | "review" | "not_confirmed";

export const STATUS_META: Record<MachineStatus, { label: string; dot: string; color: string }> = {
  disponivel: { label: "DISPONÍVEL", dot: "🟢", color: "bg-status-available" },
  negociacao: { label: "EM NEGOCIAÇÃO", dot: "🟡", color: "bg-status-negotiating" },
  vendida: { label: "VENDIDA", dot: "🔴", color: "bg-status-sold" },
  indisponivel: { label: "INDISPONÍVEL", dot: "⚪", color: "bg-status-unavailable" },
};

export const VALIDATION_STATUS_META: Record<SpecValidationStatus, { label: string; icon: string; color: string }> = {
  confirmed: { label: "CONFIRMADO", icon: "✓", color: "text-green-500" },
  review: { label: "REVISAR", icon: "⚠", color: "text-amber-500" },
  not_confirmed: { label: "NÃO CONFIRMADO", icon: "❌", color: "text-red-500" },
};

export const STATUS_OPTIONS = Object.entries(STATUS_META).map(([value, meta]) => ({
  value: value as MachineStatus,
  label: `${meta.dot} ${meta.label}`,
}));

export const PHOTO_LABELS = [
  "Principal",
  "Lateral",
  "Traseira",
  "Cabine",
  "Motor",
  "Implementos",
  "Outras",
];

export type Machine = {
  id: string;
  code: string | null;
  brand: string;
  model: string;
  /** Nome oficial da máquina — fonte única de verdade, vinda do banco. */
  display_name: string;
  category: string;
  description: string | null;
  notes: string | null;
  year: number | null;
  price: number | null;
  down_payment: number | null;
  installment: number | null;
  power: string | null;
  operating_weight: string | null;
  hours: string | null;
  location: string | null;
  condition: string | null;
  max_digging_depth: string | null;
  bucket_capacity: string | null;
  bucket_capacity_front: string | null;
  bucket_capacity_rear: string | null;
  max_reach: string | null;
  dump_height: string | null;
  engine: string | null;
  transmission: string | null;
  hydraulic_system: string | null;
  hydraulic_flow: string | null;
  hydraulic_pressure: string | null;
  digging_force: string | null;
  dimensions: string | null;
  tank_capacity: string | null;
  max_speed: string | null;
  qualities: string[] | null;
  applications: string[] | null;
  status: string;
  version_config: string | null;
  technical_source: string | null;
  technical_last_validated_at: string | null;
  technical_validated_by: string | null;
  status_power: SpecValidationStatus;
  status_operating_weight: SpecValidationStatus;
  status_max_digging_depth: SpecValidationStatus;
  status_bucket_capacity: SpecValidationStatus;
  status_max_reach: SpecValidationStatus;
  status_dump_height: SpecValidationStatus;
  status_engine: SpecValidationStatus;
  status_transmission: SpecValidationStatus;
  status_hydraulic_flow: SpecValidationStatus;
  created_at: string;
  updated_at: string;
};

export type MachineImage = {
  id: string;
  ai_generated?: boolean;
  machine_id: string;
  image_url: string;
  storage_path: string | null;
  label: string | null;
  is_main: boolean;
  sort_order: number;
  created_at: string;
};

/**
 * Nome oficial exibido para TODOS os usuários. Não compõe nome no frontend:
 * apenas lê machines.display_name (preenchido/normalizado no banco por trigger).
 */
export function machineTitle(machine: Pick<Machine, "display_name">): string {
  return machine.display_name;
}

export async function fetchMachines(): Promise<Machine[]> {
  const { data, error } = await supabase
    .from("machines")
    .select("*")
    .order("code", { ascending: true })
    .order("created_at", { ascending: true });
  if (error) throw error;
  return (data ?? []) as Machine[];
}

export async function fetchMachine(id: string): Promise<Machine | null> {
  const { data, error } = await supabase.from("machines").select("*").eq("id", id).maybeSingle();
  if (error) throw error;
  return (data ?? null) as Machine | null;
}

export async function fetchImages(machineId: string): Promise<MachineImage[]> {
  const { data, error } = await supabase
    .from("machine_images")
    .select("*")
    .eq("machine_id", machineId)
    .order("is_main", { ascending: false })
    .order("sort_order", { ascending: true });
  if (error) throw error;
  return (data ?? []) as MachineImage[];
}

/** Somente imagens ilustrativas geradas por IA — fotos reais não são exibidas no catálogo. */
export async function fetchAiImages(machineId: string): Promise<MachineImage[]> {
  const { data, error } = await supabase
    .from("machine_images")
    .select("*")
    .eq("machine_id", machineId)
    .eq("ai_generated", true)
    .order("is_main", { ascending: false })
    .order("sort_order", { ascending: true });
  if (error) throw error;
  return (data ?? []) as MachineImage[];
}

export async function fetchAllAiImages(): Promise<MachineImage[]> {
  const { data, error } = await supabase
    .from("machine_images")
    .select("*")
    .eq("ai_generated", true)
    .order("is_main", { ascending: false })
    .order("sort_order", { ascending: true });
  if (error) throw error;
  return (data ?? []) as MachineImage[];
}

export async function fetchCategories() {
  const { data, error } = await supabase
    .from("categories")
    .select("*")
    .order("name", { ascending: true });
  if (error) throw error;
  return data ?? [];
}

export type MachineChangeLog = {
  id: string;
  machine_id: string | null;
  machine_label: string;
  user_id: string | null;
  field: string;
  old_value: string | null;
  new_value: string | null;
  created_at: string;
};

export async function fetchChangeLog(): Promise<MachineChangeLog[]> {
  const { data, error } = await supabase
    .from("machine_change_log")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(200);
  if (error) throw error;
  return (data ?? []) as MachineChangeLog[];
}

export async function fetchSettings() {
  const { data, error } = await supabase.from("app_settings").select("*").limit(1).maybeSingle();
  if (error) throw error;
  return data ?? null;
}

/** Photos live in a private bucket, so display URLs are signed on demand. */
export async function signImage(image: Pick<MachineImage, "image_url" | "storage_path">) {
  const path = image.storage_path ?? image.image_url;
  if (!path) return null;
  if (path.startsWith("http")) return path;
  const { data, error } = await supabase.storage.from(MACHINE_BUCKET).createSignedUrl(path, 60 * 60);
  if (error) return null;
  return data?.signedUrl ?? null;
}

export async function signImages(images: MachineImage[]): Promise<Record<string, string>> {
  const entries = await Promise.all(
    images.map(async (image) => [image.id, await signImage(image)] as const),
  );
  return Object.fromEntries(entries.filter(([, url]) => Boolean(url)) as [string, string][]);
}

/** Accent- and case-insensitive normalization so "escavadeira" matches "ESCAVADEIRAS". */
export function normalizeText(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();
}

export function matchesSearch(machine: Machine, term: string): boolean {
  const query = normalizeText(term);
  if (!query) return true;
  const haystack = normalizeText(
    [machine.display_name, machine.brand, machine.model, machine.category, machine.code, machine.description]
      .filter(Boolean)
      .join(" "),
  );
  // Every word typed must appear somewhere (brand + model + category + code).
  return query.split(/\s+/).every((word) => haystack.includes(word));
}
