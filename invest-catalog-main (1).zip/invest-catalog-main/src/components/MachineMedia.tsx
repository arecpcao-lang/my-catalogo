import { useState } from "react";
import { ImageOff, Play, Pause } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Mídia da máquina: começa PARADA (poster) e só anima quando o usuário
 * passa o mouse (desktop) ou toca/clica (mobile). Nada anima sozinho.
 */
export function MachineMedia({
  src,
  alt,
  className,
  imageClassName,
  eager = false,
  showIllustrative = true,
  showControl = true,
}: {
  src?: string | null | undefined;
  alt: string;
  className?: string | undefined;
  imageClassName?: string | undefined;
  eager?: boolean;
  showIllustrative?: boolean;
  showControl?: boolean;
}) {
  const [pinned, setPinned] = useState(false);
  const [hovered, setHovered] = useState(false);
  const live = pinned || hovered;

  return (
    <div
      className={cn("group/media relative overflow-hidden bg-secondary", className)}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {src ? (
        <>
          <img
            src={src}
            alt={alt}
            loading={eager ? "eager" : "lazy"}
            decoding="async"
            className={cn(
              "h-full w-full object-cover will-change-transform",
              live ? "media-live" : "",
              imageClassName,
            )}
          />
          {showControl ? (
            <button
              type="button"
              onClick={(event) => {
                event.preventDefault();
                event.stopPropagation();
                setPinned((value) => !value);
              }}
              aria-label={pinned ? "Parar animação" : "Animar máquina"}
              className="absolute bottom-2 right-2 z-10 grid size-8 place-items-center rounded-full border border-border/60 bg-background/70 text-foreground opacity-80 backdrop-blur transition-opacity hover:opacity-100"
            >
              {pinned ? <Pause className="size-3.5" /> : <Play className="size-3.5" />}
            </button>
          ) : null}
          {showIllustrative ? (
            <span className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/65 to-transparent px-2 pb-1 pt-4 text-center text-[10px] font-medium uppercase tracking-[0.12em] text-white/90">
              Imagem ilustrativa
            </span>
          ) : null}
        </>
      ) : (
        <div className="flex h-full w-full flex-col items-center justify-center gap-2 bg-[repeating-linear-gradient(45deg,var(--color-secondary),var(--color-secondary)_12px,var(--color-muted)_12px,var(--color-muted)_24px)] text-muted-foreground">
          <ImageOff className="size-7" aria-hidden />
          <span className="font-display text-xs font-semibold uppercase tracking-[0.2em]">
            Mídia em preparação
          </span>
        </div>
      )}
    </div>
  );
}
