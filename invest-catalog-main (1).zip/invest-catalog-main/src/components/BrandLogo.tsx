const LOGO_SRC = "/brand/invest-logo.png";

type Size = "sm" | "md" | "lg";

const SIZES: Record<Size, string> = {
  sm: "h-8 w-8",
  md: "h-11 w-11",
  lg: "h-20 w-20",
};

/**
 * Official Invest Intermediação mark. Rendered square, never stretched or recolored.
 */
export function BrandLogo({ size = "md", className }: { size?: Size; className?: string }) {
  return (
    <img
      src={LOGO_SRC}
      alt="Invest Intermediação"
      width={512}
      height={512}
      className={`${SIZES[size]} shrink-0 rounded-md object-contain ${className ?? ""}`}
    />
  );
}
