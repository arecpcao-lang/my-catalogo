import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowRight, Check, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { MachineMedia } from "@/components/MachineMedia";
import { StatusBadge } from "@/components/StatusBadge";
import { FactoryNewBadge } from "@/components/FactoryNewBadge";
import { machineTitle, type Machine } from "@/lib/catalog";
import { illustrativeImage } from "@/lib/machineImages";
import { copyOfferToClipboard } from "@/lib/offer";
import { formatBRL } from "@/lib/format";

export function MachineCard({
  machine,
  photoUrl,
  index = 0,
}: {
  machine: Machine;
  /** Imagem ilustrativa gerada por IA (quando existir). Fotos reais não são exibidas. */
  photoUrl?: string | null | undefined;
  index?: number;
}) {
  const isSold = machine.status === "vendida";
  const displayUrl = photoUrl ?? illustrativeImage(machine);
  const [copied, setCopied] = useState(false);

  async function copyOffer() {
    const ok = await copyOfferToClipboard(machine);
    if (!ok) return;
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  }

  return (
    <article
      className="group glass enter-up relative flex flex-col overflow-hidden rounded-[1.5rem] transition-all duration-500 hover:-translate-y-1.5 hover:border-accent/40 hover:shadow-lift"
      style={{ animationDelay: `${Math.min(index, 11) * 45}ms` }}
    >
      <span
        className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-accent/60 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100"
        aria-hidden
      />
      <Link
        to="/maquina/$id"
        params={{ id: machine.id }}
        className="relative block overflow-hidden"
        aria-label={`Ver detalhes de ${machineTitle(machine)}`}
      >
        <MachineMedia
          src={displayUrl}
          alt={machineTitle(machine)}
          className="aspect-[16/11] w-full"
          imageClassName={isSold ? "grayscale" : ""}
        />
        <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-2 p-3">
          <StatusBadge status={machine.status} className="backdrop-blur" />
          {machine.code ? (
            <span className="rounded-full bg-accent px-2.5 py-0.5 font-display text-xs font-bold tracking-wide text-accent-foreground shadow-accent">
              #{machine.code}
            </span>
          ) : null}
        </div>
        {isSold ? (
          <span className="pointer-events-none absolute inset-x-0 bottom-6 bg-status-sold/90 py-1 text-center font-display text-sm font-bold uppercase tracking-[0.24em] text-surface-foreground">
            Vendida
          </span>
        ) : null}
      </Link>

      <div className="flex flex-1 flex-col gap-3.5 p-4 sm:p-5">
        <div className="min-w-0">
          <p className="label-eyebrow truncate">{machine.category}</p>
          <h3 className="truncate font-display text-2xl font-extrabold uppercase leading-tight">
            {machineTitle(machine)}
          </h3>
          <FactoryNewBadge className="mt-2" />
        </div>

        <span className="hairline-steel h-px w-full" aria-hidden />

        <div className="money-strip rounded-xl px-3 py-3">
          <p className="label-eyebrow">Valor</p>
          <p className="price-accent font-display text-[2.2rem] font-extrabold leading-none tracking-tight transition-transform duration-300 group-hover:scale-[1.02] sm:text-[2.5rem]">
            {formatBRL(machine.price)}
          </p>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div className="rounded-xl border border-border/70 bg-steel/45 px-3 py-2 transition-colors group-hover:border-silver/20">
            <p className="label-eyebrow">Entrada</p>
            <p className="font-display text-lg font-bold leading-tight sm:text-xl">
              {formatBRL(machine.down_payment)}
            </p>
          </div>
          <div className="rounded-xl border border-border/70 bg-steel/45 px-3 py-2 transition-colors group-hover:border-silver/20">
            <p className="label-eyebrow">Parcela</p>
            <p className="font-display text-lg font-bold leading-tight sm:text-xl">
              {formatBRL(machine.installment)}
            </p>
          </div>
        </div>

        <div className="mt-auto grid gap-2 pt-1">
          <Button
            type="button"
            size="lg"
            variant={copied ? "info" : "accent"}
            onClick={copyOffer}
            className="w-full rounded-xl"
            aria-label={`Copiar oferta de ${machineTitle(machine)}`}
          >
            {copied ? (
              <>
                <Check className="size-4" /> OFERTA COPIADA
              </>
            ) : (
              <>
                <Copy className="size-4" /> COPIAR OFERTA
              </>
            )}
          </Button>
          <Button asChild size="lg" variant="secondary" className="w-full rounded-xl">
            <Link to="/maquina/$id" params={{ id: machine.id }}>
              VER DETALHES <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
            </Link>
          </Button>
        </div>
      </div>
    </article>
  );
}
