import { useEffect, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { Loader2, LockKeyhole } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { bootstrapAdminStatus, createFirstAdmin } from "@/lib/users.functions";
import { BrandLogo } from "@/components/BrandLogo";


export const Route = createFileRoute("/auth")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Acesso Interno — Catálogo de Máquinas | Invest Intermediação" },
      {
        name: "description",
        content:
          "Área de acesso restrito da equipe comercial da Invest Intermediação para consultar o catálogo de máquinas pesadas.",
      },
      { property: "og:title", content: "Acesso Interno — Catálogo de Máquinas" },
      {
        property: "og:description",
        content: "Sistema interno de consulta de máquinas, valores, entradas e parcelas.",
      },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);

  const bootstrap = useQuery({
    queryKey: ["bootstrap-admin"],
    queryFn: () => bootstrapAdminStatus(),
  });

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/catalogo", replace: true });
    });
  }, [navigate]);

  const needsBootstrap = bootstrap.data?.needsBootstrap === true;

  async function handleSignIn(event: React.FormEvent) {
    event.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    setLoading(false);
    if (error) {
      toast.error("E-mail ou senha inválidos.");
      return;
    }
    navigate({ to: "/catalogo", replace: true });
  }

  async function handleBootstrap(event: React.FormEvent) {
    event.preventDefault();
    if (password.length < 8) {
      toast.error("A senha deve ter pelo menos 8 caracteres.");
      return;
    }
    setLoading(true);
    try {
      await createFirstAdmin({ data: { name: name.trim(), email: email.trim(), password } });
      const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
      if (error) throw new Error(error.message);
      toast.success("Administrador criado com sucesso!");
      navigate({ to: "/catalogo", replace: true });
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Falha ao criar administrador.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-surface px-4 py-10 text-surface-foreground">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-1.5 bg-accent"
      />
      <div className="w-full max-w-md">
        <div className="mb-8 flex flex-col items-center text-center">
          <BrandLogo size="lg" className="mb-4 shadow-lift" />
          <p className="font-display text-2xl font-extrabold uppercase tracking-wide">
            INVEST <span className="text-accent">INTERMEDIAÇÃO</span>
          </p>
          <h1 className="mt-1 font-display text-sm font-semibold uppercase tracking-[0.28em] text-surface-foreground/70">
            Catálogo de Máquinas
          </h1>
        </div>

        <div className="rounded-xl border-t-4 border-accent bg-card p-6 text-card-foreground shadow-lift">

          <div className="mb-5 flex items-center gap-2">
            <LockKeyhole className="size-5 text-muted-foreground" />
            <h2 className="font-display text-xl font-bold uppercase">
              {needsBootstrap ? "Criar administrador" : "Acesso da equipe"}
            </h2>
          </div>

          <form className="space-y-4" onSubmit={needsBootstrap ? handleBootstrap : handleSignIn}>
            {needsBootstrap ? (
              <div className="space-y-1.5">
                <Label htmlFor="name">Nome completo</Label>
                <Input
                  id="name"
                  value={name}
                  onChange={(event) => setName(event.target.value)}
                  required
                  maxLength={120}
                  autoComplete="name"
                />
              </div>
            ) : null}

            <div className="space-y-1.5">
              <Label htmlFor="email">E-mail</Label>
              <Input
                id="email"
                type="email"
                inputMode="email"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                required
                maxLength={255}
                autoComplete="username"
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="password">Senha</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                required
                minLength={needsBootstrap ? 8 : 1}
                maxLength={72}
                autoComplete={needsBootstrap ? "new-password" : "current-password"}
              />
            </div>

            <Button type="submit" size="lg" className="w-full" disabled={loading}>
              {loading ? <Loader2 className="size-4 animate-spin" /> : null}
              {needsBootstrap ? "CRIAR E ENTRAR" : "ENTRAR"}
            </Button>
          </form>

          <p className="mt-4 text-xs text-muted-foreground">
            {needsBootstrap
              ? "Nenhum administrador cadastrado ainda. Este primeiro acesso cria o administrador do sistema."
              : "Cada funcionário possui um usuário próprio. Solicite o acesso ao administrador."}
          </p>
        </div>
      </div>
    </main>
  );
}
